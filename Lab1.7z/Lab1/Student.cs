﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    public class Student : Human

    {

        private string faculty = "";

        private short course = 1;

        private short average_score = 0;

        private short[] score = new short[5];





        public Student()
        {
            Random rand = new Random();
            for (short i = 0; i < 5; i++)
            {



                score[i] = Convert.ToInt16(rand.Next(1, 6));



            }
        }

        public Student(short age, short height_cen, short

        course, short number, string

        name, string faculty, string street, string surname)

        {



            Random rand = new Random();

            address.number = number;

            address.street = street;

            this.surname = surname;

            for (short i = 0; i < 5; i++)
            {



                score[i] = Convert.ToInt16(rand.Next(1, 6));



            }



            this.age = age;

            this.height_cen = height_cen;

            this.course = course;

            this.name = name;

            this.faculty = faculty;

        }

        public string Parameters_to_save()
        {


            return (name+' '+ surname+' ' + address.street + ' ' + faculty + ' ' + Convert.ToString(age) +' ' + Convert.ToString(height_cen) + ' ' + Convert.ToString(course) + ' ' + Convert.ToString(address.number)+' ' + Convert.ToString(score[0]) + ' ' + Convert.ToString(score[1]) + ' ' + Convert.ToString(score[2]) + ' ' + Convert.ToString(score[3]) + ' ' + Convert.ToString(score[4])+"\n") ;

        }
        public short Course

        {

            set { course = value; }

            get { return course; }

        }

        
        public short[] Score
        {
            get { return score; }
        }

        public string Faculty

        {

            set { faculty = value; }

            get { return faculty; }

        }

        public int Average_score

        {

            // set { average_score = value; }

            get
            {
                average_score = 0;
                for (short i = 0; i < score.Length; i++)

                {
                    average_score += score[i];
                }
                return average_score / score.Length;

            }



        }
        public short Get_Score(short n)
        {
            return score[n];
        }
        public void Set_Score(short n, short thislo)
        {
           score[n]= thislo;
        }




        public string Get_student_type()
        {

            switch (Average_score)
            {
                case 3:

                    return"C grade";

                    break;
                case 4:

                    return "B grade";

                    break;
                case 5:

                    return "A grade";

                    break;
                default:
                    return "F grade";
                    break;
            }

        }



    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    public class Teacher_list

    {

        private List<Teacher> list_taec = new List<Teacher>();
        private short size_list_teacher = 0;


        public void Clear()
        {
            size_list_teacher = 0;
            list_taec.Clear();
        }

        public Teacher Get_teacher(short n)
        {
            var teacher = list_taec[n];

            return teacher;

        }
        public List<Teacher> Get_list_teacher()
        {
            return list_taec;
        }

        public short Size_list_teacher
        {
            get
            { return size_list_teacher; }
        }

        public Teacher List_taec

        {

            set { list_taec.Add(value);
                size_list_teacher++;
            }

            //  get { return height_cen; }

        }





    }

}

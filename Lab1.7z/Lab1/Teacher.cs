﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    public class Teacher : Human
    {
        private string faculty = "";
        private short course_students_max=5;
        private Student[] course_students = new Student[0];
        

        public Teacher() { }
        public Teacher(short age, short height_cen, short number, short course_students_max, string
        name, string faculty, string street, string surname)
        {
            address.number = number;
            address.street = street;
            this.course_students_max = course_students_max;

            this.age = age;

            this.surname = surname;

            this.height_cen = height_cen;

            this.name = name;
            this.faculty = faculty;
        }
        public string Parameters_to_save()
        {
            string text="";
            for(short i = 0; i < course_students.Length; i++)
            {
                text += ' ' + course_students[i].Name + '/' + course_students[i].Surname;


            }

            return (name + ' ' + surname + ' ' + address.street + ' ' + faculty + ' ' + Convert.ToString(age) + ' ' + Convert.ToString(height_cen) +  ' ' + Convert.ToString(address.number) + text+ "\n");

        }
        public Student Get_Course_students(short n)
          {
            return course_students[n];

          }
        public Student[] Get_Course_students_list()
        {
            return course_students;

        }
        public int Get_Course_students_size()
        {
            return course_students.Length;
        }

        public Student Course_students
        {

            set
            {
                if (course_students.Length != course_students_max)
                {
                    Student[] kistul = new Student[course_students.Length + 1];
                    for (short i = 0; i < course_students.Length; i++)
                    {

                        kistul[i] = course_students[i];


                    }

                    kistul[course_students.Length] = value;
                    course_students = kistul;

                }


            }
           
        }
       
    public short Course_students_max
        {
            set { course_students_max = value; }
            get { return course_students_max; }
        }

            public string Faculty
        { 
            set { faculty = value; } 
            get { return faculty; }
        }

    }
}

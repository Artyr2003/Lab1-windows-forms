﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    public class Student_list
    {
        private List<Student> list_student = new List<Student>();
        private short size_list_student = 0;
        public Student Get_student(short n)
        {
            var student = list_student[n];

            return student;

        }

        public short Size_list_student
        {
           get
            { return size_list_student;}
        }

        public void Clear()
        {
            size_list_student = 0;
            list_student.Clear();
        }
        public List<Student> Get_list_student()
        {
            
            return list_student;
        }


        public Student List_student

        {

            set { list_student.Add(value);
                size_list_student++;
            }

              

        }
    }
}

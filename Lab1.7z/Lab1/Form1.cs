﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.IO;
namespace Lab1
{
   
    public partial class Form1 : Form
    {
        
        Student_list student_list = new Student_list();
        Teacher_list teacher_list = new Teacher_list();
        short sive_index_student;
        //Student student = new Student(1, 2, 3, 4, "Bio", "5", "6", "Cot");

        //private List<Teacher> list_taec = new List<Teacher>();
        //list_taec.Add(new Student());

        //  Student[] student = new Student[1](1, 2, 3, 4, "Bio", "5", "6", "Cot");

       
        public void zap_grid_student()
            {
            
            DataTable table = new DataTable("?????");

            table.Columns.Add("Name", typeof(string));
            table.Columns.Add("Surname", typeof(string));
            for (short i=0;i< student_list.Size_list_student;i++) {
                table.Rows.Add(student_list.Get_student(i).Name, student_list.Get_student(i).Surname);
            }
            dataGridView1.DataSource = table;
        }

        public void zap_grid_teacher()
        {

            DataTable table = new DataTable("?????");

            table.Columns.Add("Name", typeof(string));
            table.Columns.Add("Surname", typeof(string));
            for (short i = 0; i < student_list.Size_list_student; i++)
            {
                table.Rows.Add(student_list.Get_student(i).Name);
            }
            dataGridView1.DataSource = table;
        }

        short save_student=-1, save_score=0, save_teacher = -1;

        void sive_teacher()
        {
            if (save_teacher != -1)
            {


                (teacher_list.Get_teacher(save_teacher)).Surname = textBox20.Text;
                (teacher_list.Get_teacher(save_teacher)).Name = textBox19.Text;
                (teacher_list.Get_teacher(save_teacher)).Number = Convert.ToInt16(textBox17.Text);
                (teacher_list.Get_teacher(save_teacher)).Height_cen = Convert.ToInt16(textBox16.Text);
                (teacher_list.Get_teacher(save_teacher)).Age = Convert.ToInt16(textBox15.Text);
                (teacher_list.Get_teacher(save_teacher)).Faculty = textBox14.Text;
                (teacher_list.Get_teacher(save_teacher)).Street = textBox18.Text;

                


            }
        }
        void sive_student()
        {
            if (save_student != -1)
            {
                (student_list.Get_student(save_student)).Surname = textBox1.Text;
                (student_list.Get_student(save_student)).Name = textBox2.Text;
                (student_list.Get_student(save_student)).Number = Convert.ToInt16(textBox4.Text);
                (student_list.Get_student(save_student)).Height_cen = Convert.ToInt16(textBox5.Text);
                (student_list.Get_student(save_student)).Age = Convert.ToInt16(textBox6.Text);
                (student_list.Get_student(save_student)).Course = Convert.ToInt16(textBox7.Text);
                (student_list.Get_student(save_student)).Faculty = textBox8.Text;
                (student_list.Get_student(save_student)).Street = textBox9.Text;


            }

        }
            public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
          
            this.chart1.Titles.Add("Student average score");

            teacher_list.List_taec= new Teacher(1,2, 3, 5, "yt", "ty", "jh", "ut");
            student_list.List_student = new Student(1, 2, 3, 5, "Bio", "5", "6", "Cot");
            teacher_list.Get_teacher(0).Course_students = student_list.Get_student(0);
          

            foreach (Teacher teacher in teacher_list.Get_list_teacher())
            {
                listBox3.Items.Add(teacher.Surname + "\t\t" + teacher.Name);
            }
            foreach (Student student in student_list.Get_list_student())
            {
                listBox1.Items.Add(student.Surname + "\t" + student.Name + "\t" + student.Get_student_type());
            }
         
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
            groupBox1.Enabled = true;
            
           
        }

        

        private void button2_Click(object sender, EventArgs e)
        {

            groupBox3.Visible = true;
            groupBox3.Enabled = true;
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            sive_teacher();

            save_teacher = ((short)listBox3.SelectedIndex);
            if (save_teacher != -1)
            {
                textBox20.Text = (teacher_list.Get_teacher(save_teacher)).Surname;
                textBox19.Text = (teacher_list.Get_teacher(save_teacher)).Name;
                
                textBox17.Text = Convert.ToString((teacher_list.Get_teacher(save_teacher)).Number);
                textBox16.Text = Convert.ToString((teacher_list.Get_teacher(save_teacher)).Height_cen);
                textBox15.Text = Convert.ToString((teacher_list.Get_teacher(save_teacher)).Age);
               
                textBox14.Text = (teacher_list.Get_teacher(save_teacher)).Faculty;
                textBox18.Text = (teacher_list.Get_teacher(save_teacher)).Street;
            }

            listBox3.Items.Clear();
            foreach (Teacher teacher in teacher_list.Get_list_teacher())
            {
                listBox3.Items.Add(teacher.Surname + "\t\t" + teacher.Name);
            }
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
       {
            sive_student();
            short mini_sive = save_student;
            save_student = ((short)listBox1.SelectedIndex);
            if (save_student != -1)
            {
               
                textBox1.Text = (student_list.Get_student(save_student)).Surname;
                textBox2.Text = (student_list.Get_student(save_student)).Name;
                textBox3.Text = (student_list.Get_student(save_student)).Get_student_type();
                textBox4.Text = Convert.ToString((student_list.Get_student(save_student)).Number);
                textBox5.Text = Convert.ToString((student_list.Get_student(save_student)).Height_cen);
                textBox6.Text = Convert.ToString((student_list.Get_student(save_student)).Age);
                textBox7.Text = Convert.ToString((student_list.Get_student(save_student)).Course);
                textBox8.Text = (student_list.Get_student(save_student)).Faculty;
                textBox9.Text = (student_list.Get_student(save_student)).Street;

                listBox2.Items.Clear();
                for (short i = 0; i < 5; i++)
                {
                    listBox2.Items.Add((student_list.Get_student(save_student)).Get_Score(i));
                }
            }

            listBox1.Items.Clear();
            textBox3.Text = (student_list.Get_student(save_student)).Get_student_type();

            foreach (Student student in student_list.Get_list_student())
            {
                listBox1.Items.Add(student.Surname + "\t" + student.Name + "\t" + student.Get_student_type());
            }
            if (((short)listBox2.SelectedIndex) != -1)
            {
                (student_list.Get_student(save_student)).Set_Score(save_score, Convert.ToInt16(textBox10.Text));
            }
            listBox2.Items.Clear();
            for (short i = 0; i < 5; i++)
            {
                listBox2.Items.Add((student_list.Get_student(save_student)).Get_Score(i));
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

            // listBox2.SelectedItem.;
            if (((short)listBox2.SelectedIndex)!=-1) {
                textBox10.Text = Convert.ToString(listBox2.Items[((short)listBox2.SelectedIndex)]);
                save_score = ((short)listBox2.SelectedIndex);
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {

            groupBox3.Visible = false;
            groupBox3.Enabled = false;
        }
        private void button18_Click(object sender, EventArgs e)
        {
            label16.Text = "";
            groupBox5.Visible = false;
            groupBox5.Enabled = false;
        }
        private void button6_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            groupBox1.Enabled = false;
        }

        private void button8_Click(object sender, EventArgs e)
        {

            student_list.List_student = new Student();
            student_list.Get_student(Convert.ToInt16(student_list.Size_list_student - 1)).Name+= Convert.ToString(student_list.Size_list_student-1);
            listBox1.Items.Clear();
            foreach (Student student in student_list.Get_list_student())
            {
                listBox1.Items.Add((student.Surname + "\t" + student.Name) + "\t" + student.Get_student_type());
            }
        }
      


        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

       
      
        private void button10_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
            groupBox1.Enabled = true;
            groupBox3.Visible = false;
            groupBox3.Enabled = false;
        }
        private void button7_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            groupBox1.Enabled = false;
            groupBox3.Visible = true;
            groupBox3.Enabled = true;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            label16.Text = "";
            groupBox5.Visible = false;
            groupBox5.Enabled = false;
            groupBox1.Visible = true;
            groupBox1.Enabled = true;
        }
        private void button16_Click(object sender, EventArgs e)
        {
            label16.Text = "";
            groupBox5.Visible = false;
            groupBox5.Enabled = false;
            groupBox3.Visible = true;
            groupBox3.Enabled = true;
        }
        private void button5_Click(object sender, EventArgs e)
        {
            zap_grid_student();
            listBox4.Items.Clear();
            listBox5.Items.Clear();
            chart1.Series.Clear();

            this.chart1.Palette = ChartColorPalette.SeaGreen;
            for (short i = 0; i < student_list.Size_list_student; i++)
            {
                Series series = this.chart1.Series.Add(student_list.Get_student(i).Name);
                series.Points.Add(student_list.Get_student(i).Average_score);
            }
            groupBox1.Visible = false;
            groupBox1.Enabled = false;
            groupBox5.Visible = true;
            groupBox5.Enabled = true;
            foreach (Teacher teacher in teacher_list.Get_list_teacher())
            {


                listBox5.Items.Add(teacher.Surname + "\t\t" + teacher.Name);
            }
            foreach (Student student in student_list.Get_list_student())
            {


                listBox4.Items.Add(student.Surname + "\t\t" + student.Name);
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            zap_grid_student();
            listBox4.Items.Clear();
            listBox5.Items.Clear();
            chart1.Series.Clear();

            this.chart1.Palette = ChartColorPalette.SeaGreen;
            for (short i = 0; i < student_list.Size_list_student; i++)
            {
                Series series = this.chart1.Series.Add(student_list.Get_student(i).Name);
                series.Points.Add(student_list.Get_student(i).Average_score);
            }
            groupBox3.Visible = false;
            groupBox3.Enabled = false;
            groupBox5.Visible = true;
            groupBox5.Enabled = true;
            foreach (Teacher teacher in teacher_list.Get_list_teacher())
            {


                listBox5.Items.Add(teacher.Surname + "\t\t" + teacher.Name);
            }
            foreach (Student student in student_list.Get_list_student())
            {


                listBox4.Items.Add(student.Surname + "\t\t" + student.Name);
            }
        }
        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            
            teacher_list.List_taec = new Teacher();
            listBox3.Items.Clear();
            foreach (Teacher teacher in teacher_list.Get_list_teacher())
            {
                listBox3.Items.Add(teacher.Surname + "\t\t" + teacher.Name);
            }
           
        }

      

        private void button3_Click(object sender, EventArgs e)
        {
            zap_grid_student();
            chart1.Series.Clear();

            listBox4.Items.Clear();
            listBox5.Items.Clear();

            this.chart1.Palette = ChartColorPalette.SeaGreen;

            for (short i = 0; i < student_list.Size_list_student; i++)
            {
                Series series = this.chart1.Series.Add(student_list.Get_student(i).Name);
                series.Points.Add(student_list.Get_student(i).Average_score);
            }

            foreach (Teacher teacher in teacher_list.Get_list_teacher())
            {


                listBox5.Items.Add(teacher.Surname + "\t\t" + teacher.Name);
            }

            foreach (Student student in student_list.Get_list_student())
            {
                

                listBox4.Items.Add(student.Surname + "\t\t" + student.Name);
            }

            groupBox5.Visible = true;
            groupBox5.Enabled = true;
        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            /* listBox4.Items.Clear();
             if (((short)listBox5.SelectedIndex) > -1)
             {


                 foreach (Student student in teacher_list.Get_teacher(((short)listBox5.SelectedIndex)).Get_Course_students_list())
                 {
                     listBox4.Items.Add((student.Surname + "\t" + student.Name));
                 }
             }*/
            
            sive_index_student = ((short)listBox4.SelectedIndex);

            if (sive_index_student!=-1) {
                
                pictureBox1.ImageLocation = "photo\\" + student_list.Get_student(sive_index_student).Name + ' ' + student_list.Get_student(sive_index_student).Surname + ".jpg";
            }
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
             sive_index_student =Convert.ToInt16(dataGridView1.CurrentRow.Index);

            label15.Text = Convert.ToString(sive_index_student);

        }
        private void listBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (((short)listBox5.SelectedIndex) > -1)
            {
                if (sive_index_student == -1)
                {

                    listBox4.Items.Clear();


                    foreach (Student student in teacher_list.Get_teacher(((short)listBox5.SelectedIndex)).Get_Course_students_list())
                    {
                        listBox4.Items.Add((student.Surname + "\t" + student.Name));
                    }

                }
                else
                {
                   bool kost = false;
                    for (short i = 0; i < teacher_list.Get_teacher(((short)listBox5.SelectedIndex)).Get_Course_students_size(); i++)
                    {
                        kost = kost || (student_list.Get_student(sive_index_student).Name == teacher_list.Get_teacher(((short)listBox5.SelectedIndex)).Get_Course_students(i).Name);
                    }
                    if (!kost)
                    {
                        teacher_list.Get_teacher(((short)listBox5.SelectedIndex)).Course_students = student_list.Get_student(sive_index_student);
                      
                    }
                    sive_index_student = -1;

                }
                label16.Text= "Number of students:"+ Convert.ToString(teacher_list.Get_teacher(((short)listBox5.SelectedIndex)).Get_Course_students_size() )+ "/" +Convert.ToString( teacher_list.Get_teacher(((short)listBox5.SelectedIndex)).Course_students_max);

                if (teacher_list.Get_teacher(((short)listBox5.SelectedIndex)).Get_Course_students_size() == teacher_list.Get_teacher(((short)listBox5.SelectedIndex)).Course_students_max)
                {
                    label16.ForeColor = Color.Red;
                }
                else
                {
                    label16.ForeColor = Color.Green;
                }
            
            }
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        
        private void groupBox5_Click(object sender, EventArgs e)
        {

            listBox4.Items.Clear();
            listBox5.Items.Clear();
            sive_index_student = -1;
            this.chart1.Palette = ChartColorPalette.SeaGreen;
           
            foreach (Teacher teacher in teacher_list.Get_list_teacher())
            {


                listBox5.Items.Add(teacher.Surname + "\t\t" + teacher.Name);
            }

            foreach (Student student in student_list.Get_list_student())
            {


                listBox4.Items.Add(student.Surname + "\t\t" + student.Name);
            }
        }

       
      

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (save_student != -1) {
                PictureBox Sive_photo=new PictureBox();
                OpenFileDialog open = new OpenFileDialog();
                open.Filter = "Image Files(*.BMP;*.JPG;*.GIF;*.PNG)|*.BMP;*.JPG;*.GIF;*.PNG|All files (*.*)|*.*";
                if (open.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        Sive_photo.Image = new Bitmap(open.FileName);
                         Sive_photo.Image.Save("photo\\"+ student_list.Get_student(save_student).Name+' ' + student_list.Get_student(save_student).Surname+ ".jpg");
                       
                    }
                    catch
                    {
                        DialogResult rezult = MessageBox.Show("Невозможно открыть выбранный файл",
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                } 
            }

        }

        private void button19_Click(object sender, EventArgs e)
        {

            //   label15.Text = File.ReadAllText("Sive student.txt");
            // label15.Text = File.ReadAllText("Sive student.txt");
            string text_sive="";
            for (short i = 0; i < student_list.Size_list_student; i++)
            {
                text_sive+= student_list.Get_student(i).Parameters_to_save();
            }
            

            File.WriteAllText("Sive student.json",text_sive);
            text_sive = "";
            for (short i = 0; i < teacher_list.Size_list_teacher; i++)
            {
                text_sive += teacher_list.Get_teacher(i).Parameters_to_save();
            }

            File.WriteAllText("Sive teacher.json", text_sive);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            string text_louding = "";
            string mini_text = "";
            short height_text =0;
            short width_text = 0;
           
            text_louding = File.ReadAllText("Sive student.json");
            student_list.Clear();
            //student_list.List_student = new Student();
            foreach (char cha in text_louding)
            {
                switch(cha) 
                {
                    case '\n':
                        
                        student_list.Get_student(height_text).Set_Score(4, Convert.ToInt16(mini_text));
                        width_text =0;
                        height_text++;
                        mini_text = "";

                    break;

                    case ' ':
                        switch (width_text)
                        {
                            case 0:
                                student_list.List_student = new Student();
                                student_list.Get_student(height_text).Name = mini_text;

                                break;

                            case 1:

                                student_list.Get_student(height_text).Surname = mini_text;

                                break;
                            case 2:

                                student_list.Get_student(height_text).Street = mini_text;

                                break;
                            case 3:

                                student_list.Get_student(height_text).Faculty = mini_text;

                                break;
                            case 4:

                                student_list.Get_student(height_text).Age = Convert.ToInt16(mini_text);

                                break;
                            case 5:

                                student_list.Get_student(height_text).Height_cen = Convert.ToInt16(mini_text);

                                break;
                            case 6:

                                student_list.Get_student(height_text).Course = Convert.ToInt16(mini_text);

                                break;
                            case 7:

                                student_list.Get_student(height_text).Number = Convert.ToInt16(mini_text);
                               
                                break;

                            case 8:
                            case 9:
                            case 10:
                            case 11:
                                student_list.Get_student(height_text).Set_Score(Convert.ToInt16(width_text-7), Convert.ToInt16(mini_text));

                                break;
                        }
                        width_text++;
                        mini_text = "";

                    break;

                    default:

                        mini_text += cha;

                    break;
                }
               

              

            }


              text_louding = "";
              mini_text = "";
              height_text = 0;
              width_text = 0;

            string all_name_text = "";
            short kost = 0;
            bool stud_sive=false;
            text_louding = File.ReadAllText("Sive teacher.json");
              teacher_list.Clear();

              //student_list.List_student = new Student();
              foreach (char cha in text_louding)
              {
                  switch (cha)
                  {
                      case '\n':


                        stud_sive_in_tea();
                        width_text = 0;
                          height_text++;
                          mini_text = "";
                          kost = 0;
                          stud_sive = false;
                        void stud_sive_in_tea()
                        {
                            if (stud_sive)
                            {
                                bool kostbo = false;
                                string name_text = "";
                                string surname_text = "";
                                foreach (char cha2 in all_name_text)
                                {
                                    if (kostbo)
                                    {
                                        surname_text += cha2;
                                    }

                                    if (cha2 == '/')
                                    {
                                        kostbo = true;
                                    }

                                    if (!kostbo)
                                    {
                                        name_text += cha2;
                                    }


                                }
                                for (short i = 0; i < student_list.Size_list_student ; i++) {
                                    if (student_list.Get_student(i).Name == name_text && student_list.Get_student(i).Surname == surname_text)
                                    {

                                        teacher_list.Get_teacher(height_text).Course_students = student_list.Get_student(i);
                                        break;
                                    }
                                }
                                kost++;
                                all_name_text = "";
                            }
                        }
                        break;

                      case ' ':
                          switch (width_text)
                          {
                              case 0:
                                teacher_list.List_taec = new Teacher();
                                teacher_list.Get_teacher(height_text).Name = mini_text;
                                
                                  break;

                              case 1:

                                teacher_list.Get_teacher(height_text).Surname = mini_text;

                                  break;
                              case 2:

                                teacher_list.Get_teacher(height_text).Street = mini_text;

                                  break;
                              case 3:

                                teacher_list.Get_teacher(height_text).Faculty = mini_text;

                                  break;
                              
                             
                              case 4:

                                teacher_list.Get_teacher(height_text).Age = Convert.ToInt16(mini_text);

                                  break;
                              case 5:

                                teacher_list.Get_teacher(height_text).Height_cen = Convert.ToInt16(mini_text);

                                  break;
                            case 6:
                                teacher_list.Get_teacher(height_text).Number = Convert.ToInt16(mini_text);
                                stud_sive = true;
                                break;
                                
                            default:

                                stud_sive_in_tea();

                                break;
                        }


                        
                        width_text++;
                          mini_text = "";

                          break;

                      default:
                        if (stud_sive)
                        {

                            all_name_text += cha;
                        }

                        mini_text += cha;

                          break;
                  }




              }
            
            listBox3.Items.Clear();
            listBox1.Items.Clear();
            foreach (Teacher teacher in teacher_list.Get_list_teacher())
            {
                listBox3.Items.Add(teacher.Surname + "\t\t" + teacher.Name);
            }
            foreach (Student student in student_list.Get_list_student())
            {
                listBox1.Items.Add(student.Surname + "\t" + student.Name + "\t" + student.Get_student_type());
            }

        }

        

        private void button13_Click(object sender, EventArgs e)
        {
            sive_teacher();
            listBox3.Items.Clear();
            foreach (Teacher teacher in teacher_list.Get_list_teacher())
            {
                listBox3.Items.Add(teacher.Surname + "\t\t" + teacher.Name);
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            sive_student();

            listBox1.Items.Clear();
            textBox3.Text = (student_list.Get_student(save_student)).Get_student_type();

            foreach (Student student in student_list.Get_list_student())
            {
                listBox1.Items.Add(student.Surname + "\t" + student.Name + "\t" + student.Get_student_type());
            }
            if (((short)listBox2.SelectedIndex) != -1)
            {
                (student_list.Get_student(save_student)).Set_Score(save_score, Convert.ToInt16(textBox10.Text));
            }
            listBox2.Items.Clear();
            for (short i = 0; i < 5; i++)
            {
                listBox2.Items.Add((student_list.Get_student(save_student)).Get_Score(i));
            }
        }
    }
}
